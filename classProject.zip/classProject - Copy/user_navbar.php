<html>
    <head>
        <style>
            p{
                    text-align: center;
            }
        </style>
    </head>
    <body>
        <p>
            <a href="user_home.php">Home</a>&nbsp;|&nbsp;
            <a href="user_profile.php">View and Update Profile</a>&nbsp;|&nbsp;
            <a href="phpquiz.php">Take the PHP Quiz</a>&nbsp;|&nbsp;
            <a href="sqlquiz.php">Take the SQL Quiz</a>&nbsp;|&nbsp;
            <a href="htmlquiz.php">Take the HTML/CSS Quiz</a>&nbsp;|&nbsp;
            <a href="javascriptquiz.php">Take the JavaScript Quiz</a>&nbsp;|&nbsp;
            <a href="user_result.php">Check Results</a>&nbsp;|&nbsp;
            <a href="index.php">Logout</a>&nbsp;|&nbsp;

        </p>
    </body>
</html>