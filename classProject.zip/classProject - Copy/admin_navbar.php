<html>
    <head>
        <title>Online Test - Admin Nav</title>
        <style>
            p{
                text-align: center;
            }
        </style>
    </head>
    <body>
        <p aling ='center'>
            <a href="admin_home.php">Home</a>&nbsp;|&nbsp;
            <a href="admin_display.php">Display All Users</a>&nbsp;|&nbsp;
            <a href="index.php">Logout</a>&nbsp;|&nbsp;
            
        </p>
    </body>
</html>