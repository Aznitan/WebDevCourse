
<html>
<head>
    
    <title>Document</title>
    <style>
        h3,body{
            text-align: center;
        }
    </style>
</head>
<body>
    <h3>Thanks you for registering with us!</h3>
    Please <a href="index.php">click here</a> to log in.
</body>
</html>