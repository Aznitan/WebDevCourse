<html>
    <head>
        <title>Online Test - Admin Home</title>
        <style>
            p,h2{
                text-align: center;
                padding-top: 5rem;
            }
        </style>
    </head>
    <body>
        
        <h2>Welcome to the Admin Portal </h2>
        <p>Admin will be able to delate/update users, check user evaluation results.</p>

    <?php
    include ("admin_navbar.php");
    
    ?>


    </body>
</html>