<html>
    <head>
        
<link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <p>
            <a href="admin_home.php">Personal Profile</a>&nbsp;|&nbsp;
            <a href="admin_announce.php">Create Announcement</a>&nbsp;|&nbsp;
            <a href="admin_manage_s.php">Manage Students</a>&nbsp;|&nbsp;
            <a href="admin_manage_v.php">Manage Volunteers</a>&nbsp;|&nbsp;
            <a href="admin_student_temp.php">Student Need Temp Housing</a>&nbsp;|&nbsp;
            <a href="admin_assing_housing.php">Assing Housing Volunteer</a>&nbsp;|&nbsp;
            <a href="index.php">Logout</a>&nbsp;|&nbsp;

        </p>
        <p>
        |<a href="admin_student_pick.php">Student Need Pickup</a>&nbsp;|&nbsp;
        <a href="admin_assing_pick">Assing Pickup Volunteer</a>&nbsp;|&nbsp;
        </p>
    </body>
</html>