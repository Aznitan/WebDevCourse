<html>
    <head>
        
<link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <p>
            <a href="v_home.php">Home</a>&nbsp;|&nbsp;
            <a href="v_profile.php">Personal Profile</a>&nbsp;|&nbsp;
            <a href="v_car.php">Car Infor</a>&nbsp;|&nbsp;
            <a href="v_house.php">House Infor</a>&nbsp;|&nbsp;
            <a href="v_pick.php">Pickup Assingment</a>&nbsp;|&nbsp;
            <a href="v_temp.php">Temp Housing Assingment</a>&nbsp;|&nbsp;
            <a href="p_needs.php">Check Pickup Needs</a>&nbsp;|&nbsp;
            <a href="index.php">Logout</a>&nbsp;|&nbsp;

        </p>
    </body>
</html>