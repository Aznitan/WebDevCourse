<html>
    <head>
        
<link rel="stylesheet" href="style.css" type="text/css">
    </head>
    <body>
        <p>
            <a href="student_home.php">Home</a>&nbsp;|&nbsp;
            <a href="student_profile.php">Personal Profile</a>&nbsp;|&nbsp;
            <a href="student_fli.php">Flight Infor</a>&nbsp;|&nbsp;
            <a href="studnet_temp_need.php">Temp Housing Need</a>&nbsp;|&nbsp;
            <a href="student_pick.php">Pickup Information</a>&nbsp;|&nbsp;
            <a href="student_temp.php">Temp Housing Information</a>&nbsp;|&nbsp;
            <a href="index.php">Logout</a>&nbsp;|&nbsp;

        </p>
    </body>
</html>