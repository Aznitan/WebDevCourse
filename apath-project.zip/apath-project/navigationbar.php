<html>
    <head>
        <style>
            p{
                align-items: center;
            }
        </style>
    </head>
    <body>
        <p>
            <a href="home.php">Home</a>&nbsp;|&nbsp;
            <a href="about.php">About</a>&nbsp;|&nbsp;
            <a href="login.php">Login</a>&nbsp;|&nbsp;
            <a href="registration.php">Sign Up</a>&nbsp;|&nbsp;
            <a href="forum.php">Forum</a>&nbsp;|&nbsp;
            <a href="contact.php">Contact</a>&nbsp;|&nbsp;
        </p>

    </body>
</html>